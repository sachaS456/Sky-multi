﻿namespace Vlc.DotNet.Core
{
    public interface ITracksManagement : IEnumerableManagement<TrackDescription>
    {
    }
}
