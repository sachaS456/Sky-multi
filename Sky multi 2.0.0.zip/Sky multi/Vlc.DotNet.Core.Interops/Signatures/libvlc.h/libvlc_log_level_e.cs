﻿namespace Vlc.DotNet.Core.Interops.Signatures
{
    public enum VlcLogLevel
      : int
    {
        Debug = 0,
        Notice = 2,
        Warning = 3,
        Error = 4
    }
}
