﻿namespace Vlc.DotNet.Core.Interops.Signatures
{
    public enum AudioOutputChannels
    {
        Error = -1,
        Stereo = 1,
        RStereo = 2,
        Left = 3,
        Right = 4,
        Dolbys = 5,
    }
}
