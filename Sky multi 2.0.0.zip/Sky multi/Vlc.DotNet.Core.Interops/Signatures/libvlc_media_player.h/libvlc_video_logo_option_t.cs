﻿namespace Vlc.DotNet.Core.Interops.Signatures
{
    public enum VideoLogoOptions
    {
        Enable = 0,
        File,
        X,
        Y,
        Delay,
        Repeat,
        Opacity,
        Position
    }
}
