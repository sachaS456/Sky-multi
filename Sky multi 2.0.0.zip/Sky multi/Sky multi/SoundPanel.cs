﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_multi
{
    internal delegate void EventSoundHandler(sbyte Volume);
    
    internal partial class SoundPanel : UserControl
    {
        private bool BarClique = false;
        private sbyte VolumeV = 100;
        internal EventSoundHandler EventSoundVolume = null;

        internal SoundPanel()
        {
            InitializeComponent();

            progessBar1.EventMove += new EventProgressBarMousseHandler(progessBar1_MouseMove);
            progessBar1.EventDown += new EventProgressBarMousseHandler(progessBar1_MouseDown);
            progessBar1.EventUp += new EventProgressBarMousseHandler(progessBar1_MouseUp);
        }

        protected virtual void VolumeChanged()
        {
            if (EventSoundVolume != null)
            {
                EventSoundVolume(VolumeV);
            }
        }

        private void progessBar1_MouseDown(int X, int Y, MouseButtons mouseButtons)
        {
            BarClique = true;
        }

        private void progessBar1_MouseUp(int X, int Y, MouseButtons mouseButtons)
        {
            BarClique = false;
        }

        private void progessBar1_MouseMove(int X, int Y, MouseButtons mouseButtons)
        {
            if (BarClique == true)
            {
                if (X <= 0)
                {
                    VolumeV = 0;
                    progessBar1.Valeur = 0;
                    label1.Text = "Volume : 0%";
                    button15.BackgroundImage.Dispose();
                    button15.BackgroundImage = Image.FromFile(Application.StartupPath + "no son2.png");
                }
                else if (X >= 194)
                {
                    VolumeV = 100;
                    progessBar1.Valeur = 100;
                    label1.Text = "Volume : 100%";
                }
                else
                {
                    VolumeV = (sbyte)(X * 100 / progessBar1.Size.Width + 1);
                    progessBar1.Valeur = VolumeV;
                    label1.Text = "Volume : " + VolumeV + "%";
                    button15.BackgroundImage.Dispose();
                    button15.BackgroundImage = Image.FromFile(Application.StartupPath + "full son2.png");
                }

                VolumeChanged();
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (VolumeV == 0)
            {
                VolumeV = 100;
                progessBar1.Valeur = 100;
                label1.Text = "Volume : 100%";
                button15.BackgroundImage.Dispose();
                button15.BackgroundImage = Image.FromFile(Application.StartupPath + "full son2.png");
            }
            else
            {
                VolumeV = 0;
                progessBar1.Valeur = 0;
                label1.Text = "Volume : 0%";
                button15.BackgroundImage.Dispose();
                button15.BackgroundImage = Image.FromFile(Application.StartupPath + "no son2.png");
            }

            VolumeChanged();
        }
    }
}
