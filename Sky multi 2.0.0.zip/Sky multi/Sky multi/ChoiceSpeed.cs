﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_multi
{
    internal delegate void EventSpeedHandler(ref float Speed, ref bool SpeedMore);

    internal partial class ChoiceSpeed : UserControl
    {
        internal EventSpeedHandler EventSpeedChanged = null;
        private bool Cache = true;

        internal ChoiceSpeed()
        {
            InitializeComponent();
        }

        protected virtual void EventSpeedChangedM(float Speed, bool SpeedMore)
        {
            CacheThis();

            if (EventSpeedChanged != null)
            {
                EventSpeedChanged(ref Speed, ref SpeedMore);
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            // ultra rapide
            EventSpeedChangedM(3.0f, true);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EventSpeedChangedM(2.0f, true);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EventSpeedChangedM(1.5f, true);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // normal
            EventSpeedChangedM(1.0f, true);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            EventSpeedChangedM(1.5f, false);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            EventSpeedChangedM(2.0f, false);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // ultra lent
            EventSpeedChangedM(3.0f, false);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (Cache == true)
            {
                this.Visible = true;
                this.Size = new Size(this.Size.Width, this.Size.Height + 15);
                this.Location = new Point(this.Location.X, this.Location.Y - 15);

                if (this.Size.Height >= 262)
                {
                    this.Size = new Size(this.Size.Width, 262);
                    timer1.Enabled = false;
                    Cache = false;
                }
            }
            else
            {
                this.Size = new Size(this.Size.Width, this.Size.Height - 15);
                this.Location = new Point(this.Location.X, this.Location.Y + 15);

                if (this.Size.Height <= 0)
                {
                    this.Size = new Size(this.Size.Width, 0);
                    this.Visible = false;
                    timer1.Enabled = false;
                    Cache = true;
                }
            }
        }

        internal void CacheThis()
        {
            if (Cache == false)
            {
                timer1.Enabled = true;
            }
        }

        internal void MontreThis()
        {
            if (Cache == true)
            {
                timer1.Enabled = true;
            }
        }
    }
}
