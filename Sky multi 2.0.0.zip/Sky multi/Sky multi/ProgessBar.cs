﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_multi
{
    internal delegate void EventProgressBarMousseHandler(int X, int Y, MouseButtons mouseButtons);

    internal partial class ProgessBar : UserControl
    {
        private sbyte _valeur;
        internal event EventProgressBarMousseHandler EventDown = null;
        internal event EventProgressBarMousseHandler EventMove = null;
        internal event EventProgressBarMousseHandler EventUp = null;

        internal ProgessBar()
        {
            InitializeComponent();

            Size = new Size(200, 30);
            _valeur = 100;
            ElementProgress.Size = new Size((_valeur / 100) * Width, Height);
        }

        protected virtual void ExecuterEvenementDown(int X, int Y, MouseButtons mouseButtons)
        {
            if (EventDown != null)
            {
                EventDown(X, Y, mouseButtons);
            }
        }

        protected virtual void ExecuterEvenementMove(int X, int Y, MouseButtons mouseButtons)
        {
            if (EventMove != null)
            {
                EventMove(X, Y, mouseButtons);
            }
        }

        protected virtual void ExecuterEvenementUp(int X, int Y, MouseButtons mouseButtons)
        {
            if (EventUp != null)
            {
                EventUp(X, Y, mouseButtons);
            }
        }

        internal sbyte Valeur
        {
            get
            {
                return _valeur;
            }
            set
            {
                _valeur = value;
                progressUpdate();
            }
        }

        internal Color CouleurFond
        {
            get
            {
                return this.BackColor;
            }
            set
            {
                this.BackColor = value;
            }
        }

        internal Color Couleur
        {
            get
            {
                return ElementProgress.BackColor;
            }
            set
            {
                ElementProgress.BackColor = value;
            }
        }

        private void progressUpdate()
        {
            if (_valeur >= 0 && _valeur <= 100)
            {
                ElementProgress.Size = new Size((int)((float)((float)_valeur / 100) * Width - 4), Height - 4);
            }
            else if (_valeur < 0)
            {
                ElementProgress.Size = new Size(0, Height - 4);
                _valeur = 0;
            }
            else if (_valeur > 100)
            {
                ElementProgress.Size = new Size(Width - 4, Height - 4);
                _valeur = 100;
            }
        }

        private void PogessBar_Resize(object sender, EventArgs e)
        {
            progressUpdate();
        }

        private void ElementProgress_MouseDown(object sender, MouseEventArgs e)
        {
            ExecuterEvenementDown(e.X, e.Y, e.Button);
        }

        private void ElementProgress_MouseMove(object sender, MouseEventArgs e)
        {
            ExecuterEvenementMove(e.X, e.Y, e.Button);
        }

        private void ProgessBar_MouseDown(object sender, MouseEventArgs e)
        {
            ExecuterEvenementDown(e.X, e.Y, e.Button);
        }

        private void ProgessBar_MouseMove(object sender, MouseEventArgs e)
        {
            ExecuterEvenementMove(e.X, e.Y, e.Button);
        }

        private void ElementProgress_MouseUp(object sender, MouseEventArgs e)
        {
            ExecuterEvenementUp(e.X, e.Y, e.Button);
        }

        private void ProgessBar_MouseUp(object sender, MouseEventArgs e)
        {
            ExecuterEvenementUp(e.X, e.Y, e.Button);
        }
    }
}
