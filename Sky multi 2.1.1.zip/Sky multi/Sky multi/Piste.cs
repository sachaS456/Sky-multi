﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_multi
{
    internal partial class Piste : UserControl
    {
        private bool View = true;
        private List<ButtonPerso> ListButton = new List<ButtonPerso>();
        internal EventButtonPersoHandler EventButtonPerso = null;
        private int SizeControlHeight = 0;
        private bool SubTitles = false;

        internal Piste()
        {
            InitializeComponent();
        }

        private void ConfigNewButton(string Text)
        {
            ButtonPerso buttonPerso = new ButtonPerso(ListButton.Count());
            if (ListButton.Count() == 0)
            {
                buttonPerso.Location = new Point(0, 0);
            }
            else
            {
                buttonPerso.Location = new Point(0, ListButton[ListButton.Count() - 1].Location.Y + 36);
            }
            buttonPerso.EventCliqueHandler += new EventButtonPersoHandler(ButtonPersoClique);
            buttonPerso.LabelText = Text;
            ListButton.Add(buttonPerso);
            this.Controls.Add(ListButton[ListButton.Count() - 1]);
        }

        private void ButtonPersoClique(ref int ID)
        {
            if (EventButtonPerso != null)
            {
                if (SubTitles)
                {
                    ID--;
                }

                EventButtonPerso(ref ID);

                if (SubTitles)
                {
                    ID++;
                }
            }
        }

        internal bool GetView
        {
            get
            {
                return View;
            }
        }

        internal void Montre(Vlc.DotNet.Core.ITracksManagement tracks)
        {
            SubTitles = false;
            SizeControlHeight = 0;
            for (int index = 0; index < tracks.Count; index++)
            {
                ConfigNewButton(tracks.All.ToList()[index].Name);
                SizeControlHeight += 36;
            }

            if (SizeControlHeight == 0)
            {
                SizeControlHeight = 36;
            }

            if (View == false)
            {
                timer1.Enabled = true;
            }
        }

        internal void Montre(Vlc.DotNet.Core.ISubTitlesManagement tracks)
        {
            SubTitles = true;
            SizeControlHeight = 36;
            ConfigNewButton("Choose File");
            for (int index = 0; index < tracks.Count; index++)
            {
                ConfigNewButton(tracks.All.ToList()[index].Name);
                SizeControlHeight += 36;
            }

            if (View == false)
            {
                timer1.Enabled = true;
            }
        }

        internal void Cache()
        {
            if (View == true)
            {
                timer1.Enabled = true;
            }

            // supression des boutons + libération de la mémoire
            for (int index = 0; index < ListButton.Count(); index++)
            {
                ListButton[index].Dispose();
            }

            ListButton.Clear();
            this.Controls.Clear();
            this.EventButtonPerso = null;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (View == false)
            {
                this.Visible = true;
                this.Size = new Size(this.Size.Width, this.Size.Height + 15);
                this.Location = new Point(this.Location.X, this.Location.Y - 15);

                if (this.Size.Height >= SizeControlHeight)
                {
                    this.Size = new Size(this.Size.Width, SizeControlHeight);
                    timer1.Enabled = false;
                    View = true;
                }
            }
            else
            {
                this.Size = new Size(this.Size.Width, this.Size.Height - 15);
                this.Location = new Point(this.Location.X, this.Location.Y + 15);

                if (this.Size.Height <= 0)
                {
                    this.Size = new Size(this.Size.Width, 0);
                    this.Visible = false;
                    timer1.Enabled = false;
                    View = false;
                }
            }
        }
    }
}
