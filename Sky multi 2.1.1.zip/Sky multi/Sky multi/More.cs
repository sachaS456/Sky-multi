﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_multi
{
    internal delegate void EventMoreHandler();

    internal partial class More : UserControl
    {
        private bool View = true;
        internal EventMoreHandler EventSpecificTime = null;
        internal EventMoreHandler EventReadingSpeed = null;
        internal EventMoreHandler EventPisteVideo = null;
        internal EventMoreHandler EventPisteAudio = null;
        internal EventMoreHandler EventPisteSousTitre = null;

        internal More()
        {
            InitializeComponent();
        }

        protected virtual void EventSpecificTimeM()
        {
            if (EventSpecificTime != null)
            {
                EventSpecificTime();
            }
        }

        protected virtual void EventReadingSpeedM()
        {
            if (EventReadingSpeed != null)
            {
                EventReadingSpeed();
            }
        }

        protected virtual void EventPisteVideoM()
        {
            if (EventPisteVideo != null)
            {
                EventPisteVideo();
            }
        }

        protected virtual void EventPisteAudioM()
        {
            if (EventPisteAudio != null)
            {
                EventPisteAudio();
            }
        }

        protected virtual void EventPisteSousTitreM()
        {
            if (EventPisteSousTitre != null)
            {
                EventPisteSousTitre();
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            EventSpecificTimeM();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EventReadingSpeedM();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EventPisteVideoM();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            EventPisteAudioM();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            EventPisteSousTitreM();
        }

        internal bool GetView
        {
            get
            {
                return View;
            }
        }

        internal void Montre()
        {
            if (View == false)
            {
                timer1.Enabled = true;
            }
        }

        internal void Cache()
        {
            if (View == true)
            {
                timer1.Enabled = true;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (View == false)
            {
                this.Visible = true;
                this.Size = new Size(this.Size.Width, this.Size.Height + 15);
                this.Location = new Point(this.Location.X, this.Location.Y - 15);

                if (this.Size.Height >= 191)
                {
                    this.Size = new Size(this.Size.Width, 191);
                    timer1.Enabled = false;
                    View = true;
                }
            }
            else
            {
                this.Size = new Size(this.Size.Width, this.Size.Height - 15);
                this.Location = new Point(this.Location.X, this.Location.Y + 15);

                if (this.Size.Height <= 0)
                {
                    this.Size = new Size(this.Size.Width, 0);
                    this.Visible = false;
                    timer1.Enabled = false;
                    View = false;
                }
            }
        }

        internal void TraduireBoutton(sbyte language)
        {
            switch (language)
            {
                case 0:
                    button1.Text = Language.Francais.MoreButton1;
                    button16.Text = Language.Francais.MoreButton16;
                    button2.Text = Language.Francais.MoreButton2;
                    button3.Text = Language.Francais.MoreButton3;
                    button4.Text = Language.Francais.MoreButton4;
                    break;

                case 1:
                    button1.Text = Language.English.MoreButton1;
                    button16.Text = Language.English.MoreButton16;
                    button2.Text = Language.English.MoreButton2;
                    button3.Text = Language.English.MoreButton3;
                    button4.Text = Language.English.MoreButton4;
                    break;
            }
        }
    }
}
