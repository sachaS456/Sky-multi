﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_multi
{
    internal partial class Reglage : Form
    {
        private bool FormCache = false;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;
        private bool Annulerv = true;

        internal Reglage(ref bool ApercueProgressBarc, ref bool ApercueDefTimec, sbyte Langagec)
        {
            InitializeComponent();

            this.Opacity = 0;

            timer1.Enabled = true;

            checkBox1.Checked = ApercueProgressBarc;
            checkBox2.Checked = ApercueDefTimec;

            comboBox1.Items.Add("Français");
            comboBox1.Items.Add("English");

            comboBox1.SelectedIndex = Langagec;

            switch (Langagec)
            {
                case 0: // FR
                    button1.Text = Language.Francais.ReglageButton1;
                    button4.Text = Language.Francais.ReglageButton4;
                    checkBox1.Text = Language.Francais.ReglageCheckbox1;
                    checkBox2.Text = Language.Francais.ReglageCheckbox2;
                    label1.Text = Language.Francais.ReglageLabel1;
                    label2.Text = Language.Francais.ReglageLabel2;
                    label6.Text = Language.Francais.ReglageLabel6;
                    break;

                case 1: // EN
                    button1.Text = Language.English.ReglageButton1;
                    button4.Text = Language.English.ReglageButton4;
                    checkBox1.Text = Language.English.ReglageCheckbox1;
                    checkBox2.Text = Language.English.ReglageCheckbox2;
                    label1.Text = Language.English.ReglageLabel1;
                    label2.Text = Language.English.ReglageLabel2;
                    label6.Text = Language.English.ReglageLabel6;
                    break;
            }
        }       

        private void button3_Click(object sender, EventArgs e)
        {
            Annulerv = true;
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    this.Close();
                }
            }
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
            }
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                FormDeplace = false;
            }
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Save
            Annulerv = false;
            timer1.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Cancel
            Annulerv = true;
            timer1.Enabled = true;
        }

        internal bool Annuler
        {
            get
            {
                return Annulerv;
            }
        }

        internal bool ApercueProgressBar
        {
            get
            {
                return checkBox1.Checked;
            }
        }

        internal bool ApercueDefTime
        {
            get
            {
                return checkBox2.Checked;
            }
        }

        internal int Langage
        {
            get
            {
                return comboBox1.SelectedIndex;
            }
        }
    }
}
