﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Sky_multi
{
    internal partial class TempsSpecifique : Form
    {
        private long M_vlcNewTime = 0;
        private bool M_Annuler = true;
        private int H;
        private long M;
        private long S;
        private string VideoLecture;
        private bool FormCache = false;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;
        private bool NoChiffre = false;
        private bool ApercueTime;

        internal TempsSpecifique(ref int H1, ref long M1, ref long S1, ref string VideoLecture1, ref bool ApercueTimec, sbyte langage)
        {
            InitializeComponent();

            H = H1;
            M = M1;
            S = S1;
            VideoLecture = VideoLecture1;
            this.Opacity = 0;
            ApercueTime = ApercueTimec;

            switch (langage)
            {
                case 0: // FR
                    button1.Text = Language.Francais.TempsSpecifiqueButton1;
                    button2.Text = Language.Francais.TempsSpecifiqueButton2;
                    label1.Text = Language.Francais.TempsSpecifiqueLabel1;
                    label2.Text = Language.Francais.TempsSpecifiqueLabel2;
                    label3.Text = Language.Francais.TempsSpecifiqueLabel3;
                    label6.Text = Language.Francais.TempsSpecifiqueLabel6;
                    break;

                case 1: // EN
                    button1.Text = Language.English.TempsSpecifiqueButton1;
                    button2.Text = Language.English.TempsSpecifiqueButton2;
                    label1.Text = Language.English.TempsSpecifiqueLabel1;
                    label2.Text = Language.English.TempsSpecifiqueLabel2;
                    label3.Text = Language.English.TempsSpecifiqueLabel3;
                    label6.Text = Language.English.TempsSpecifiqueLabel6;
                    break;
            }
        }

        private void TempsSpecifique_Load(object sender, EventArgs e)
        {
            // heures definition
            DomainUpDown.DomainUpDownItemCollection collectionH = this.domainUpDown1.Items;
            for (int nbBoucle = 1000; nbBoucle > -1; nbBoucle--)
            {
                collectionH.Add(nbBoucle.ToString());
            }

            // minute definition
            DomainUpDown.DomainUpDownItemCollection collectionM = this.domainUpDown2.Items;
            for (int nbBoucle = 59; nbBoucle > -1; nbBoucle--)
            {
                collectionM.Add(nbBoucle.ToString());
            }

            // seconde definition
            DomainUpDown.DomainUpDownItemCollection collectionS = this.domainUpDown3.Items;
            for (int nbBoucle = 59; nbBoucle > -1; nbBoucle--)
            {
                collectionS.Add(nbBoucle.ToString());
            }

            domainUpDown3.SelectedIndex = (int)(59 - S);
            domainUpDown2.SelectedIndex = (int)(59 - M);
            domainUpDown1.SelectedIndex = 1000 - H;

            if (ApercueTime == true)
            {
                if (File.Exists(VideoLecture))
                {
                    vlcControl1.Play(new Uri(VideoLecture));
                    System.Threading.Thread.Sleep(100);
                    vlcControl1.Pause();
                }
            }
            else
            {
                vlcControl1 = null;
            }
            timer2.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // bouton annuler
            if (vlcControl1 != null)
            {
                vlcControl1.Stop();
            }
            timer2.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // bouton aller à

            long Heure;
            sbyte Minute;
            sbyte Seconde;

            if (domainUpDown1.Text == string.Empty)
            {
                Heure = 0;
            }
            else
            {
                Heure = Convert.ToInt64(domainUpDown1.Text);
            }

            if (domainUpDown2.Text != string.Empty)
            {
                if (Convert.ToInt64(domainUpDown2.Text) > 59)  // verif minute si + de 59 min
                {
                    Minute = 59;
                }
                else
                {
                    Minute = Convert.ToSByte(domainUpDown2.Text);
                }
            }
            else
            {
                Minute = 0;
            }

            if (domainUpDown3.Text != string.Empty)
            {
                if (Convert.ToInt64(domainUpDown3.Text) > 59)  // verif seconde si + de 59 s
                {
                    Seconde = 59;
                }
                else
                {
                    Seconde = Convert.ToSByte(domainUpDown3.Text);
                }
            }
            else
            {
                Seconde = 0;
            }

            if (Minute > 59)
            {
                Minute = 59;
            }
            if (Seconde > 59)
            {
                Seconde = 59;
            }

            M_vlcNewTime = (Heure * 60 * 60 * 1000) + (Minute * 60 * 1000) + (Seconde * 1000);
            M_Annuler = false;
            vlcControl1.Stop();
            timer2.Enabled = true;
        }

        internal long vlcNewTime
        {
            get
            {
                return M_vlcNewTime;
            }
        }

        internal bool Annuler
        {
            get
            {
                return M_Annuler;
            }
        }

        private void vlcControl1_VlcLibDirectoryNeeded(object sender, Vlc.DotNet.Forms.VlcLibDirectoryNeededEventArgs e)
        {
            if (Environment.Is64BitProcess)
            {
                e.VlcLibDirectory = new System.IO.DirectoryInfo(Application.StartupPath + @"\libvlc\win-x64");
            }
            else
            {
                e.VlcLibDirectory = new System.IO.DirectoryInfo(Application.StartupPath + @"\libvlc\win-x86");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            long HeureT;
            sbyte MinuteT;
            sbyte SecondeT;

            if (domainUpDown1.Text == string.Empty)
            {
                HeureT = 0;
            }
            else
            {
                HeureT = Convert.ToInt64(domainUpDown1.Text);
            }

            if (domainUpDown2.Text != string.Empty)
            {
                if (Convert.ToInt64(domainUpDown2.Text) > 59)  // verif minute si + de 59 min
                {
                    MinuteT = 59;
                    domainUpDown2.SelectedIndex = 0;
                }
                else
                {
                    MinuteT = Convert.ToSByte(domainUpDown2.Text);
                }
            }
            else
            {
                MinuteT = 0;
            }

            if (domainUpDown3.Text != string.Empty)
            {
                if (Convert.ToInt64(domainUpDown3.Text) > 59)  // verif seconde si + de 59 s
                {
                    SecondeT = 59;
                    domainUpDown3.SelectedIndex = 0;
                }
                else
                {
                    SecondeT = Convert.ToSByte(domainUpDown3.Text);
                }
            }
            else
            {
                SecondeT = 0;
            }

            if (MinuteT > 59)
            {
                MinuteT = 59;
            }
            if (SecondeT > 59)
            {
                SecondeT = 59;
            }

            if (vlcControl1 != null)
            {
                long time = (HeureT * 60 * 60 * 1000) + (MinuteT * 60 * 1000) + (SecondeT * 1000);

                if (time > vlcControl1.Length)
                {
                    vlcControl1.Time = vlcControl1.Length - 1;
                }
                else
                {
                    vlcControl1.Time = time;
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            // animation de form arrêt ou démarre
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer2.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer2.Enabled = false;
                    this.Close();
                }
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            // déplacement active car souris préssée
            if (e.Button == MouseButtons.Left && this.Cursor == Cursors.Default)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
                return;
            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            // déplacement de la fenêtre
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            FormDeplace = false;
        }

        private void domainUpDown1_KeyDown(object sender, KeyEventArgs e)
        {
            KeyPressMethode(ref e, 1);
        }

        private void domainUpDown2_KeyDown(object sender, KeyEventArgs e)
        {
            KeyPressMethode(ref e, 2);
        }

        private void domainUpDown3_KeyDown(object sender, KeyEventArgs e)
        {
            KeyPressMethode(ref e, 3);
        }

        private void KeyPressMethode(ref KeyEventArgs e, sbyte ID)
        {
            if (e.KeyCode == Keys.D0 || e.KeyCode == Keys.D1 || e.KeyCode == Keys.D2 || e.KeyCode == Keys.D3 || e.KeyCode == Keys.D4 || e.KeyCode == Keys.D5 ||
                e.KeyCode == Keys.D6 || e.KeyCode == Keys.D7 || e.KeyCode == Keys.D8 || e.KeyCode == Keys.D9)
            {
                switch (e.KeyCode)
                {
                    case Keys.D0:
                        DefHorraire(0, ref ID);
                        break;

                    case Keys.D1:
                        DefHorraire(1, ref ID);
                        break;

                    case Keys.D2:
                        DefHorraire(2, ref ID);
                        break;

                    case Keys.D3:
                        DefHorraire(3, ref ID);
                        break;

                    case Keys.D4:
                        DefHorraire(4, ref ID);
                        break;

                    case Keys.D5:
                        DefHorraire(5, ref ID);
                        break;

                    case Keys.D6:
                        DefHorraire(6, ref ID);
                        break;

                    case Keys.D7:
                        DefHorraire(7, ref ID);
                        break;

                    case Keys.D8:
                        DefHorraire(8, ref ID);
                        break;

                    case Keys.D9:
                        DefHorraire(9, ref ID);
                        break;
                }
                NoChiffre = true;
                return;
            }

            if (e.KeyCode == Keys.NumPad0 || e.KeyCode == Keys.NumPad1 || e.KeyCode == Keys.NumPad2 || e.KeyCode == Keys.NumPad3 || e.KeyCode == Keys.NumPad4 ||
                e.KeyCode == Keys.NumPad5 || e.KeyCode == Keys.NumPad6 || e.KeyCode == Keys.NumPad7 || e.KeyCode == Keys.NumPad8 || e.KeyCode == Keys.NumPad9 || e.KeyCode == Keys.Back)
            {
                NoChiffre = false;
            }
            else
            {
                NoChiffre = true;
            }
        }

        private void DefHorraire(int value, ref sbyte ID)
        {
            switch (ID)
            {
                case 1:
                    domainUpDown1.Text += value.ToString();
                    domainUpDown1.SelectedIndex = 1000 - Convert.ToInt32(domainUpDown1.Text);
                    domainUpDown1.Select(domainUpDown1.Text.Length, 0);
                    break;

                case 2:
                    domainUpDown2.Text += value.ToString();
                    if (Convert.ToInt32(domainUpDown2.Text) > 59)
                    {
                        domainUpDown1.SelectedIndex -= 1;
                        domainUpDown2.SelectedIndex = 0;
                    }
                    else
                    {
                        domainUpDown2.SelectedIndex = 59 - Convert.ToInt32(domainUpDown2.Text);
                    }
                    domainUpDown2.Select(domainUpDown2.Text.Length, 0);
                    break;

                case 3:
                    domainUpDown3.Text += value.ToString();
                    if (Convert.ToInt32(domainUpDown3.Text) > 59)
                    {
                        if (domainUpDown2.SelectedIndex == 0)
                        {
                            domainUpDown2.SelectedIndex = 0;
                            domainUpDown1.SelectedIndex -= 1;
                        }
                        else
                        {
                            domainUpDown2.SelectedIndex -= 1;
                        }
                        domainUpDown3.SelectedIndex = 0;
                    }
                    else
                    {
                        domainUpDown3.SelectedIndex = 59 - Convert.ToInt32(domainUpDown3.Text);
                    }
                    domainUpDown3.Select(domainUpDown3.Text.Length, 0);
                    break;
            }
        }

        private void domainUpDown_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = NoChiffre;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Ferme cette form et annule le temps spécifier
            vlcControl1.Stop();
            timer2.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
