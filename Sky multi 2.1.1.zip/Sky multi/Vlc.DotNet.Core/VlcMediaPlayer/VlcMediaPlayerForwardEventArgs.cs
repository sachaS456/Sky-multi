﻿using System;

namespace Vlc.DotNet.Core
{
    public sealed class VlcMediaPlayerForwardEventArgs : EventArgs
    {
    }
}