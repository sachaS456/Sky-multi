﻿namespace Vlc.DotNet.Core.Interops.Signatures
{
    public enum MediaTrackTypes : int
    {
        Unknown = -1,
        Audio = 0,
        Video = 1,
        Text = 2
    }
}
