﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sky_multi
{
    internal class Language
    {
        internal struct Francais
        {
            internal const string FormPrincipalButton7 = "Ouvrir";
            internal const string FormPrincipalButton6 = "Pleine écran";
            internal const string FormPrincipalButton5 = "Reglage";
            internal const string FormPrincipalButton1 = "Quitter";
            internal const string FormPrincipalLabel1 = "Durée du media :\n 00h00min00s";

            internal const string ReglageButton1 = "Sauvegarder";
            internal const string ReglageButton4 = "Annuler";
            internal const string ReglageLabel6 = "Réglages Sky multi";
            internal const string ReglageLabel1 = "Apeçue vidéo";
            internal const string ReglageLabel2 = "Langage";
            internal const string ReglageCheckbox1 = "Aperçue vidéo de la barre de\nprogression";
            internal const string ReglageCheckbox2 = "Aperçue vidéo lors de la\ndéfinition du temps du\nmultimedia";

            internal const string InfoFileLabel6 = "Information fichier Sky multi";
            internal const string InfoFileLabel8 = "À propos de l'application :";
            internal const string InfoFileLabel9 = "Information de la video :";
            internal const string InfoFileLabel10 = "Information de l'audio :";
            internal const string InfoFileLinkLabel1 = "Acceder au site";
            internal const string InfoFileLinkLabel2 = "Acceder site de VideoLan";

            internal const string TempsSpecifiqueLabel1 = "Heure(s)";
            internal const string TempsSpecifiqueLabel2 = "Minute(s)";
            internal const string TempsSpecifiqueLabel3 = "Seconde(s)";
            internal const string TempsSpecifiqueLabel6 = "Définir un temps spécifié à Sky multi";
            internal const string TempsSpecifiqueButton1 = "Aller à";
            internal const string TempsSpecifiqueButton2 = "Annuler";

            internal const string MoreButton16 = "Aller à un temps spécifié";
            internal const string MoreButton1 = "Vitesse de lecture";
            internal const string MoreButton2 = "Piste vidéo";
            internal const string MoreButton3 = "Piste audio";
            internal const string MoreButton4 = "Piste de sous titres";
        }

        internal struct English
        {
            internal const string FormPrincipalButton7 = "Open";
            internal const string FormPrincipalButton6 = "Full screen";
            internal const string FormPrincipalButton5 = "Setting";
            internal const string FormPrincipalButton1 = "Leave";
            internal const string FormPrincipalLabel1 = "Media duration :\n 00h00min00s";

            internal const string ReglageButton1 = "Save";
            internal const string ReglageButton4 = "Cancel";
            internal const string ReglageLabel6 = "Settings Sky multi";
            internal const string ReglageLabel1 = "Video preview";
            internal const string ReglageLabel2 = "Language";
            internal const string ReglageCheckbox1 = "Video preview of the bar\nprogression";
            internal const string ReglageCheckbox2 = "Video preview during the\ntime definition\nmultimedia";

            internal const string InfoFileLabel6 = "Sky multi file information";
            internal const string InfoFileLabel8 = "About the app :";
            internal const string InfoFileLabel9 = "Video Information :";
            internal const string InfoFileLabel10 = "Audio Information :";
            internal const string InfoFileLinkLabel1 = "Access the site";
            internal const string InfoFileLinkLabel2 = "Access the site of VideoLan";

            internal const string TempsSpecifiqueLabel1 = "Hour(s)";
            internal const string TempsSpecifiqueLabel2 = "Minute(s)";
            internal const string TempsSpecifiqueLabel3 = "Second(s)";
            internal const string TempsSpecifiqueLabel6 = "Define a specific time for Sky multi";
            internal const string TempsSpecifiqueButton1 = "Go to";
            internal const string TempsSpecifiqueButton2 = "Cancel";

            internal const string MoreButton16 = "Go in a specific time";
            internal const string MoreButton1 = "Reading speed";
            internal const string MoreButton2 = "Video track";
            internal const string MoreButton3 = "Audio track";
            internal const string MoreButton4 = "Subtitles track";
        }
    }
}
