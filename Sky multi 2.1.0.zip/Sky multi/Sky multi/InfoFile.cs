﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Sky_multi
{
    internal partial class InfoFile : Form
    {
        private bool FormCache = false;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;

        internal InfoFile(ref string FilePath, Color ThemeMode, string Temps, ref string codecVideo, ref string Hauteur, ref string Largeur, ref string codecSon, ref string Cannaux,
            ref string Rate, ref string Orientation, sbyte language)
        {
            InitializeComponent();

            this.Opacity = 0;
            this.BackColor = ThemeMode;

            switch (language)
            {
                case 0: // FR
                    label10.Text = Language.Francais.InfoFileLabel10;
                    label6.Text = Language.Francais.InfoFileLabel6;
                    label8.Text = Language.Francais.InfoFileLabel8;
                    label9.Text = Language.Francais.InfoFileLabel9;
                    linkLabel1.Text = Language.Francais.InfoFileLinkLabel1;
                    linkLabel2.Text = Language.Francais.InfoFileLinkLabel2;
                    break;

                case 1: // EN
                    label10.Text = Language.English.InfoFileLabel10;
                    label6.Text = Language.English.InfoFileLabel6;
                    label8.Text = Language.English.InfoFileLabel8;
                    label9.Text = Language.English.InfoFileLabel9;
                    linkLabel1.Text = Language.English.InfoFileLinkLabel1;
                    linkLabel2.Text = Language.English.InfoFileLinkLabel2;

                    label12.Text = "Height : ";
                    label13.Text = "Width : ";
                    label15.Text = "canals : ";
                    label14.Text = "sampling frequency : ";

                    label7.Text = "Sky multi\n\nVersion: 2.1.0\n\nDeveloped by Sacha Himber \n\nThis player is based on VLC media player.\ntherefore allows you to read everything with\n" +
                        "improved visual comfort!\n\nVersion of LibVLC:";
                    break;
            }

            if (ThemeMode == Color.FromArgb(64, 64, 64))
            {
                label1.ForeColor = Color.FromArgb(224, 224, 224);
                label2.ForeColor = Color.FromArgb(224, 224, 224);
                label3.ForeColor = Color.FromArgb(224, 224, 224);
                label4.ForeColor = Color.FromArgb(224, 224, 224);
                label5.ForeColor = Color.FromArgb(224, 224, 224);
                button1.ForeColor = Color.FromArgb(224, 224, 224);
            }
            else
            {
                label1.ForeColor = Color.Black;
                label2.ForeColor = Color.Black;
                label3.ForeColor = Color.Black;
                label4.ForeColor = Color.Black;
                label5.ForeColor = Color.Black;
                button1.ForeColor = Color.Black;
            }

            timer1.Enabled = true;

            if (FilePath != "")
            {
                switch (language)
                {
                    case 0:
                        label1.Text = "Nom du fichier : " + Path.GetFileName(FilePath);
                        toolTip2.SetToolTip(this.label1, Path.GetFileName(FilePath));
                        label2.Text = "Chemin de fichier : " + FilePath;
                        toolTip1.SetToolTip(this.label2, FilePath);
                        label3.Text = "Taille : " + EspaceNombre(new FileInfo(FilePath).Length / 1000000) + " mo";

                        label4.Text = "Type de fichier : " + Path.GetExtension(FilePath);
                        label5.Text = "Date de création : " + File.GetCreationTime(FilePath);
                        label17.Text = "Temps de la video : " + Temps;
                        break;

                    case 1:
                        label1.Text = "Name file : " + Path.GetFileName(FilePath);
                        toolTip2.SetToolTip(this.label1, Path.GetFileName(FilePath));
                        label2.Text = "File path : " + FilePath;
                        toolTip1.SetToolTip(this.label2, FilePath);
                        label3.Text = "Size : " + EspaceNombre(new FileInfo(FilePath).Length / 1000000) + " mo";

                        label4.Text = "File type : " + Path.GetExtension(FilePath);
                        label5.Text = "Creation date : " + File.GetCreationTime(FilePath);
                        label17.Text = "Video time : " + Temps;
                        break;
                }
                label11.Text += codecVideo;
                if (Largeur != string.Empty)
                {
                    label12.Text += Largeur + " pixels";
                }

                if (Hauteur != string.Empty)
                {
                    label13.Text += Hauteur + " pixels";
                }
                label16.Text += codecSon;
                label15.Text += Cannaux;
                if (Rate != string.Empty)
                {
                    label14.Text += Rate + " Hz";
                }
                label18.Text += Orientation;
            }
            else
            {
                switch (language)
                {
                    case 0:
                        label1.Text = "Nom du fichier : ";
                        label2.Text = "Chemin de fichier : ";
                        toolTip1.SetToolTip(this.label2, FilePath);
                        label3.Text = "Taille : ";
                        label4.Text = "Type de fichier : ";
                        label5.Text = "Date de création : ";
                        label17.Text = "Temps de la video : ";
                        break;

                    case 1:
                        label1.Text = "Name file : ";
                        label2.Text = "File path : ";
                        toolTip1.SetToolTip(this.label2, FilePath);
                        label3.Text = "Size : ";
                        label4.Text = "File type : ";
                        label5.Text = "Creation date : ";
                        label17.Text = "Video time : ";
                        break;
                }
            }

            label7.Text += VersionLibVlc;
        }

        internal static string VersionLibVlc
        {
            get
            {
                return "3.0.12";
            }
        }

        private string EspaceNombre(double element)
        {
            string elementString = element.ToString();
            List<char> chaineString = new List<char>();

            foreach (char i in elementString)
            {
                chaineString.Add(i);
            }

            int index = 0;
            chaineString.Reverse();
            List<char> chaineModif = new List<char>();

            foreach (char i in chaineString)
            {
                if (index == 3)
                {
                    chaineModif.Add(' ');
                    index = 0;
                }
                chaineModif.Add(i);

                index++;
            }

            chaineModif.Reverse();
            string ARetourner = string.Empty;

            foreach (char i in chaineModif)
            {
                ARetourner += i;
            }

            /* Liberation de la mémoire */
            chaineString.Clear();
            chaineModif.Clear();
            elementString = string.Empty;

            /* Liberation de la mémoire */
            chaineString = null;
            elementString = null;
            chaineModif = null;           

            return ARetourner;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    this.Close();
                }
            }
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
            }
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                FormDeplace = false;
            }
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel1.LinkVisited = true;
            Process process = new Process();
            process.StartInfo.UseShellExecute = true;
            process.StartInfo.FileName = "https://serie-sky.netlify.app/index.html";
            process.Start();
            process.Close();
            process = null;
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel2.LinkVisited = true;
            Process process = new Process();
            process.StartInfo.UseShellExecute = true;
            process.StartInfo.FileName = "https://www.videolan.org/legal.html";
            process.Start();
            process.Close();
            process = null;
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel3.LinkVisited = true;
            if (File.Exists(Application.StartupPath + "COPYING.txt"))
            {
                Process process = new Process();
                process.StartInfo.UseShellExecute = true;
                process.StartInfo.FileName = Application.StartupPath + "COPYING.txt";
                process.Start();
                process.Close();
                process = null;
            }
            else
            {
                MessageBox.Show("Une erreur est survenue, le fichier est introuvable. Veuillez le retélécharger le logiciel pour corriger ce problème", 
                    "Sky multi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
