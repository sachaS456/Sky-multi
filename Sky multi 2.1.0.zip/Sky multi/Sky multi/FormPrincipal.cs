﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Vlc.DotNet.Core.Interops;

namespace Sky_multi
{
    internal partial class FormPrincipal : Form
    {
        private int LocX = 0;
        private int LocY = 0;
        private bool FormDeplace = false;
        private bool FormCache = false;
        private bool BarClique = false;
        private bool pause = false;
        private byte Coter = 0;
        private int panel2Y = 0;
        private bool FSBarreVisible = true;
        private int MouseX = 0;
        private int MouseY = 0;
        private string FileNameMedia = string.Empty;
        private bool MediaFini = false;
        private const int MiniLargeForm = 818;
        private const int MiniHautForm = 514;
        private bool ApercueProgressBar = true;
        private bool ApercueTime = true;
        private SoundPanel SoundPanel = new SoundPanel();
        private ChoiceSpeed ChoiceSpeed = new ChoiceSpeed();
        private More more = new More();
        private Piste Piste = new Piste();
        private sbyte Langage = 0;

        internal FormPrincipal()
        {
            InitializeComponent();

            this.Select();
            this.Opacity = 0;
            timer1.Enabled = true;

            progessBar1.EventDown += new EventProgressBarMousseHandler(this.progessBar1_Down);
            progessBar1.EventMove += new EventProgressBarMousseHandler(this.progessBar1_Move);
            progessBar1.EventUp += new EventProgressBarMousseHandler(this.progessBar1_Up);

            SoundPanel.Visible = false;
            SoundPanel.Location = new Point(500, 350);
            SoundPanel.Anchor = AnchorStyles.Bottom;
            SoundPanel.EventSoundVolume += new EventSoundHandler(SoundPanel_Volume);
            panel1.Controls.Add(SoundPanel);

            ChoiceSpeed.Visible = false;
            ChoiceSpeed.Location = new Point(270, 450);
            ChoiceSpeed.Size = new Size(ChoiceSpeed.Size.Width, 0);
            ChoiceSpeed.Anchor = AnchorStyles.Bottom;
            ChoiceSpeed.EventSpeedChanged += new EventSpeedHandler(ChoiceSpeed_Speed);
            panel1.Controls.Add(ChoiceSpeed);

            more.Location = new Point(25, 240);
            more.Anchor = AnchorStyles.Bottom;
            more.Cache();
            more.EventSpecificTime += new EventMoreHandler(TempsSpecifier);
            more.EventReadingSpeed += new EventMoreHandler(ChoixVitesseLecture);
            more.EventPisteVideo += new EventMoreHandler(PisteVideo);
            more.EventPisteAudio += new EventMoreHandler(PisteAudio);
            more.EventPisteSousTitre += new EventMoreHandler(PisteSousTitre);
            panel1.Controls.Add(more);

            Piste.Location = new Point(270, 200);
            Piste.Anchor = AnchorStyles.Bottom;
            Piste.Cache();
            Piste.BringToFront();
            panel1.Controls.Add(Piste);
        }
        #region formConfig
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            vlcControl1.Stop();
        }

        private void FormPrincipal_MouseMove(object sender, MouseEventArgs e)
        {
            // déplacement de la fenêtre
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }

            this.Cursor = Cursors.Default;
            button2.Cursor = Cursors.Default;

            if (e.X >= this.Size.Width - 2 && e.Y >= this.Size.Height - 2)
            {
                // agrandit ou réduit coin bas droite
                this.Cursor = Cursors.SizeNWSE;
                return;
            }

            if (e.X <= 2 && e.Y >= this.Size.Height - 2)
            {
                // agrandit ou réduit coin bas gauche
                this.Cursor = Cursors.SizeNESW;
                return;
            }

            if (e.X <= 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut gauche
                this.Cursor = Cursors.SizeNWSE;
                return;
            }

            if (e.X == this.Size.Width - 1)
            {
                // agrandit ou réduit coté droite
                this.Cursor = Cursors.SizeWE;
                button2.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.X == 0)
            {
                // agrandit ou réduit coté gauche
                this.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.Y == this.Size.Height - 1)
            {
                // agrandit ou réduit coté bas
                this.Cursor = Cursors.SizeNS;
                return;
            }

            if (e.Y == 0)
            {
                // agrandit ou réduit coté haut
                this.Cursor = Cursors.SizeNS;
                button2.Cursor = Cursors.SizeNS;
                return;
            }
        }


        private void button2_MouseMove(object sender, MouseEventArgs e)
        {
            button2.Cursor = Cursors.Default;


            if (e.X >= button2.Size.Width - 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut droite
                button2.Cursor = Cursors.SizeNESW;
                return;
            }

            if (e.X == button2.Size.Width - 1)
            {
                // droite
                button2.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.Y == 1)
            {
                // haut
                button2.Cursor = Cursors.SizeNS;
                return;
            }
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.X >= button2.Size.Width - 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut droite
                Coter = 5;
                timer3.Enabled = true;
                return;
            }

            if (e.X == button2.Size.Width - 2)
            {
                // agrandit ou réduit coté droite

                Coter = 1;
                timer3.Enabled = true;
                return;
            }

            if (e.Y == 1)
            {
                // agrandit ou réduit coté haut
                Coter = 3;
                timer3.Enabled = true;
                return;
            }
        }

        private void FormPrincipal_MouseDown(object sender, MouseEventArgs e)
        {
            // déplacement active car souris préssée
            if (e.Button == MouseButtons.Left && this.Cursor == Cursors.Default)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
                return;
            }

            if (this.Cursor != Cursors.Default)
            {
                /// Coin :

                if (e.X >= this.Size.Width - 2 && e.Y >= this.Size.Height - 2)
                {
                    // agrandit ou réduit coin bas droite
                    Coter = 8;
                    timer3.Enabled = true;
                    return;
                }

                if (e.X <= 2 && e.Y >= this.Size.Height - 2)
                {
                    // agrandit ou réduit coin bas gauche
                    Coter = 7;
                    timer3.Enabled = true;
                    return;
                }

                if (e.X >= this.Size.Width - 2 && e.Y <= 2)
                {
                    // agrandit ou réduit coin haut droite
                    Coter = 5;
                    timer3.Enabled = true;
                    return;
                }

                if (e.X <= 2 && e.Y <= 2)
                {
                    // agrandit ou réduit coin haut gauche
                    Coter = 6;
                    timer3.Enabled = true;
                    return;
                }

                /// cotée :

                if (e.X == 0)
                {
                    // agrandit ou réduit coté gauche

                    Coter = 2;
                    timer3.Enabled = true;
                    return;
                }

                if (e.X == this.Size.Width - 1)
                {
                    // agrandit ou réduit coté droite

                    Coter = 1;
                    timer3.Enabled = true;
                    return;
                }

                if (e.Y == this.Size.Height - 1)
                {
                    // agrandit ou réduit coté bas
                    Coter = 4;
                    timer3.Enabled = true;
                    return;
                }

                if (e.Y == 0)
                {
                    // agrandit ou réduit coté haut
                    Coter = 3;
                    timer3.Enabled = true;
                    return;
                }
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            switch (Coter)
            {
                case 1:  // côtée droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, this.Size.Height);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height);
                    }
                    break;

                case 2: // côtée gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), this.Size.Height);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height);
                    }
                    break;

                case 3:  // côtée haut
                    if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(this.Size.Width, MiniHautForm);
                    }
                    break;

                case 4:  // côtée bas
                    if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(this.Size.Width, MiniHautForm);
                    }
                    break;

                case 5:  // coin haut droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm && this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MiniHautForm);
                    }
                    else if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 6:  // coin haut gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm && this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(MousePosition.X, MousePosition.Y);
                    }
                    else if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MiniHautForm);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 7:  // coin bas gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm && MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MousePosition.Y - this.Location.Y);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MiniHautForm);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 8:  // coin bas droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm && MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MousePosition.Y - this.Location.Y);
                    }
                    else if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MiniHautForm);
                    }
                    else if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;
            }
        }

        private void FormPrincipal_MouseUp(object sender, MouseEventArgs e)
        {
            timer3.Enabled = false;
            Coter = 0;
            FormDeplace = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.Cursor == Cursors.Default)
            {
                timer1.Enabled = true;
                vlcControl1.Stop();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // fenêtre normal ou agrandit
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void vlcControl1_VlcLibDirectoryNeeded(object sender, Vlc.DotNet.Forms.VlcLibDirectoryNeededEventArgs e)
        {
            // vlcControl config bibliothèque x64 ou x86
            if (Environment.Is64BitProcess == true)
            {
                e.VlcLibDirectory = new System.IO.DirectoryInfo(Application.StartupPath + @"\libvlc\win-x64");
            }
            else
            {
                e.VlcLibDirectory = new System.IO.DirectoryInfo(Application.StartupPath + @"\libvlc\win-x86");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // animation de form arrêt ou démarre
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    Environment.Exit(0);
                }
            }
        }

        private void FormPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            vlcControl1.Stop();
            timer1.Enabled = true;
            e.Cancel = true;
        }

        #endregion

        private void button5_Click(object sender, EventArgs e)
        {
            // Lance réglage
            using (Reglage reglage = new Reglage(ref ApercueProgressBar, ref ApercueTime, Langage))
            {
                reglage.ShowDialog();

                // appliquer reglage
                if (reglage.Annuler == false)
                {
                    using (StreamWriter writer = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Sky multi\appSettings"))
                    {
                        writer.Write(reglage.ApercueProgressBar + "\n" + reglage.ApercueDefTime + "\n" + reglage.Langage);
                        writer.Close();
                    }

                    RéglageApplique();
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)  // Full Screen
        {
            // active ou désactive plein écran
            if (vlcControl1.Location == new Point(0, 0)) // si full sreen
            {
                // Désactive Plein écran
                if (FileNameMedia != string.Empty)
                {
                    timer2.Enabled = true;
                }
                timer4.Enabled = false;
                if (panel2Y != 0)
                {
                    panel2.Location = new Point(panel2.Location.X, panel2Y);
                }
                FSBarreVisible = true;
                this.WindowState = FormWindowState.Normal;
                panel1.Size = new Size(this.Size.Width - 4, this.Size.Height - 30);
                panel1.Location = new Point(2, 28);
                vlcControl1.Size = new Size(panel1.Size.Width - 112, panel1.Size.Height - 77);
                vlcControl1.Location = new Point(112, 0);
                panel2.Controls.Remove(button6);
                panel1.Controls.Add(button6);
                button6.Anchor = AnchorStyles.Top | AnchorStyles.Left;
                button6.Location = new Point(-1, 108);
                vlcControl2.Location = new Point(vlcControl2.Location.X, vlcControl2.Location.Y + (vlcControl2.Size.Height / 2));
                vlcControl2.Size = new Size(vlcControl2.Size.Width / 2, vlcControl2.Size.Height / 2);

                label2.Visible = true;
                pictureBox1.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                button2.Visible = true;
                timer5.Enabled = false;
            }
            else
            {
                // Active Plein écran
                panel1.Controls.Remove(button6);
                panel2.Controls.Add(button6);
                button6.Location = new Point(1, 26);
                button6.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
                this.WindowState = FormWindowState.Maximized;
                this.Cursor = Cursors.Default;
                panel1.Size = new Size(this.Size.Width, this.Size.Height);
                panel1.Location = new Point(0, 0);
                vlcControl1.Size = new Size(this.Size.Width, this.Size.Height);
                vlcControl1.Location = new Point(0, 0);
                vlcControl2.Size = new Size(vlcControl2.Size.Width * 2, vlcControl2.Size.Height * 2);
                vlcControl2.Location = new Point(vlcControl2.Location.X, vlcControl2.Location.Y - (vlcControl2.Size.Height / 2));
                vlcControl1.BringToFront();
                panel2.BringToFront();
                button6.BringToFront();

                label2.Visible = false;
                pictureBox1.Visible = false;
                button3.Visible = false;
                button4.Visible = false;
                button2.Visible = false;
                timer5.Enabled = true;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // ouvrir un fichier
            OpenFileDialog dialogOuvre = new OpenFileDialog();
            if (Langage == 0)
            {
                dialogOuvre.Filter = "Tous les fichiers|*.*";
            }
            else
            {
                dialogOuvre.Filter = "All the files|*.*";
            }

            if (dialogOuvre.ShowDialog() == DialogResult.OK)
            {
                if (File.Exists(dialogOuvre.FileName))
                {
                    if (pause == true)
                    {
                        button8.BackgroundImage = Image.FromFile(Application.StartupPath + @"\Pause.png");
                        pause = false;
                    }
                    vlcControl1.Play(new Uri(dialogOuvre.FileName));
                    FileNameMedia = dialogOuvre.FileName;
                    timer2.Enabled = true;
                    MediaFini = false;
                }
                else
                {
                    if (Langage == 0)
                    {
                        MessageBox.Show("Fichier introuvable!", "Sky multi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show("File not found!", "Sky multi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            dialogOuvre.Dispose();
        }

        private string ConvertVlcTimeToString(long VlcTime, bool DureeMedia = true)
        {
            long second = VlcTime / 1000;
            long minute = second / 60;
            long heure = minute / 60;

            second = second - 60 * minute;
            minute = minute - 60 * heure;
            if (second < 0)
            {
                minute--;
                second = 60 + second;
            }
            if (minute < 0)
            {
                heure--;
                minute = 60 + minute;
            }

            if (DureeMedia == true)
            {
                if (Langage == 0)
                {
                    return "Durée du media :\n  " + heure + "h" + minute + "min" + second + "s";
                }
                else
                {
                    return "Media duration :\n  " + heure + "h" + minute + "min" + second + "s";
                }
            }
            else
            {
                return heure + "h" + minute + "min" + second + "s";
            }
        }

        #region progressBarConfig
        private void progessBar1_Move(int X, int Y, MouseButtons e)
        {
            if (BarClique == true)
            {
                if (X <= 0)
                {
                    progessBar1.Valeur = 0;
                }
                else
                {
                    progessBar1.Valeur = (sbyte)(X * 100 / progessBar1.Size.Width + 1);
                }

                if (ApercueProgressBar == true)
                {
                    if (vlcControl2.Time != (long)((double)progessBar1.Valeur / 100 * vlcControl2.Length))
                    {
                        vlcControl2.Location = new Point(X - 64, vlcControl2.Location.Y);
                    }
                }
            }
        }

        private void progessBar1_Down(int X, int Y, MouseButtons e)
        {
            BarClique = true;
            SoundPanel.Visible = false;
            ChoiceSpeed.CacheThis();
            more.Cache();
            Piste.Cache();
            if (ApercueProgressBar == true && GetVideo() == true)
            {
                if (File.Exists(FileNameMedia))
                {
                    vlcControl2.Visible = true;
                    vlcControl2.Play(new Uri(FileNameMedia));
                    System.Threading.Thread.Sleep(100);
                    vlcControl2.BringToFront();
                    vlcControl2.Pause();
                }
                timer7.Enabled = true;
            }
        }

        private void progessBar1_Up(int X, int Y, MouseButtons e)
        {
            BarClique = false;
            timer7.Enabled = false;
            vlcControl2.Stop();
            vlcControl2.Visible = false;

            if (MediaFini == true)
            {
                if (File.Exists(FileNameMedia))
                {
                    vlcControl1.Play(new Uri(FileNameMedia));
                    System.Threading.Thread.Sleep(100);
                }
                else
                {
                    if (Langage == 0)
                    {
                        MessageBox.Show("Une erreur est survenue! Le fichier est introuvable.", "Sky multi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show("An error has occurred! The file cannot be found. ", "Sky multi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                MediaFini = false;
            }

            if (X <= 0)
            {
                progessBar1.Valeur = 0;
            }
            else
            {
                progessBar1.Valeur = (sbyte)(X * 100 / progessBar1.Size.Width + 1);
            }
            vlcControl1.Time = (long)((double)progessBar1.Valeur / 100 * vlcControl1.Length);
        }
        #endregion

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (vlcControl1.Time > 0 && vlcControl1.Length > 0) // correction de stabilité
            {
                if (MediaFini == false)
                {
                    progessBar1.Valeur = (sbyte)(vlcControl1.Time * 100 / vlcControl1.Length);
                }
                else
                {
                    progessBar1.Valeur = 100;
                }
                label3.Text = ConvertVlcTimeToString(vlcControl1.Time, false);
            }

            if (MediaFini == true)
            {
                label3.Text = ConvertVlcTimeToString(vlcControl1.Length, false);
                MultimediaDroite();   // à modifier pour une futur fonctionnalité
                MediaFini = false;
            }

            if (ConvertVlcTimeToString(vlcControl1.Length) != label1.Text)
            {
                label1.Text = ConvertVlcTimeToString(vlcControl1.Length);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (FileNameMedia != string.Empty)
            {
                vlcPause();
            }
        }

        private void vlcPause()
        {
            if (MediaFini == true)
            {
                if (File.Exists(FileNameMedia))
                {
                    vlcControl1.Play(new Uri(FileNameMedia));
                }
                else
                {
                    if (Langage == 0)
                    {
                        MessageBox.Show("Une erreur est survenue! Le fichier est introuvable.", "Sky multi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show("An error has occurred! The file cannot be found. ", "Sky multi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                label3.Text = ConvertVlcTimeToString(vlcControl1.Time, false);
                MediaFini = false;

                button8.BackgroundImage.Dispose();
                button8.BackgroundImage = Image.FromFile(Application.StartupPath + @"\Pause.png");
                pause = false;

                return;
            }

            vlcControl1.Pause();
            button8.BackgroundImage.Dispose();
            if (pause == true)
            {
                button8.BackgroundImage = Image.FromFile(Application.StartupPath + @"\Pause.png");
                pause = false;
            }
            else
            {
                button8.BackgroundImage = Image.FromFile(Application.StartupPath + @"\Play.png");
                pause = true;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            // - 1 minute
            vlcControl1.Time -= 60000;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            // + 1 minute
            vlcControl1.Time += 60000;
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            // Animation panel2 montre ou se cache en pleine écran
            if (FSBarreVisible == false)
            {
                // il faut montrer
                panel2.Location = new Point(panel2.Location.X, panel2.Location.Y - 5);

                if (panel2.Location.Y <= panel2Y)
                {
                    if (FileNameMedia != string.Empty)
                    {
                        timer2.Enabled = true;
                    }
                    timer4.Enabled = false;
                    panel2.Location = new Point(panel2.Location.X, panel2Y);
                    FSBarreVisible = true;
                }
            }
            else
            {
                // il faut cacher
                panel2.Location = new Point(panel2.Location.X, panel2.Location.Y + 5);

                if (panel2.Location.Y >= panel2Y + panel2.Size.Height)
                {
                    timer4.Enabled = false;
                    FSBarreVisible = false;
                    panel2.Visible = false;
                    timer2.Enabled = false;
                }
            }
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            // Détecter en pleine écran si l'utilisateur veut faire appaître la bar de progression et les boutons
            if (vlcControl1.Location == new Point(0, 0)) // si full screen
            {
                if (MousePosition.X == MouseX && MousePosition.Y == MouseY && MousePosition.Y < panel2.Location.Y && FSBarreVisible == true && BarClique == false && SoundPanel.Visible == false)
                {
                    // Cacher
                    timer5.Enabled = false;
                    timer6.Enabled = true;                 
                }
                else if (MousePosition.Y >= panel2Y + 45 && FSBarreVisible == false && timer4.Enabled == false)
                {
                    // Montrer
                    panel2.Location = new Point(panel2.Location.X, panel2Y + panel2.Size.Height);
                    timer4.Enabled = true;
                    panel2.Visible = true;
                }
                MouseX = MousePosition.X;
                MouseY = MousePosition.Y;
            }
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            timer5.Enabled = true;
            if (MousePosition.X == MouseX && MousePosition.Y == MouseY && vlcControl1.Location == new Point(0, 0) && SoundPanel.Visible == false)
            {
                if (FSBarreVisible == true && timer4.Enabled == false && BarClique == false)
                {
                    // Cacher
                    panel2Y = panel2.Location.Y;
                    timer4.Enabled = true;
                }
            }
            else if (vlcControl1.Location != new Point(0, 0))
            {
                timer5.Enabled = false;
            }
            timer6.Enabled = false;
        }

        private void TempsSpecifier()
        {
            // boutton temps spécifier

            long secondlong = vlcControl1.Time / 1000;
            long minutelong = secondlong / 60;
            int heure = (int)minutelong / 60;

            secondlong = secondlong - 60 * minutelong;
            minutelong = minutelong - 60 * heure;

            if (secondlong < 0)
            {
                minutelong--;
                secondlong = 60 + secondlong;
            }

            if (minutelong < 0)
            {
                heure--;
                minutelong = 60 + minutelong;
            }

            TempsSpecifique form = new TempsSpecifique(ref heure, ref minutelong, ref secondlong, ref FileNameMedia, ref ApercueTime, Langage);
            form.ShowDialog();

            if (form.Annuler == false)
            {
                vlcControl1.Time = form.vlcNewTime;
            }

            form.Dispose();
            form = null;
        }

        private void vlcControl2_VlcLibDirectoryNeeded(object sender, Vlc.DotNet.Forms.VlcLibDirectoryNeededEventArgs e)
        {
            if (Environment.Is64BitProcess == true)
            {
                e.VlcLibDirectory = new System.IO.DirectoryInfo(Application.StartupPath + @"\libvlc\win-x64");
            }
            else
            {
                e.VlcLibDirectory = new System.IO.DirectoryInfo(Application.StartupPath + @"\libvlc\win-x86");
            }
        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            if ((long)((double)progessBar1.Valeur / 100 * vlcControl2.Length) != vlcControl2.Time)
            {
                vlcControl2.Time = (long)((double)progessBar1.Valeur / 100 * vlcControl2.Length);
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            // info fichier

            string CodecVideo = string.Empty,
                Hauteur = string.Empty,
                Largeur = string.Empty,
                CodecSon = string.Empty,
                Cannaux = string.Empty,
                Rate = string.Empty,
                Orientation = string.Empty;

            if (FileNameMedia != string.Empty)
            {
                foreach (MediaTrack i in vlcControl1.GetCurrentMedia().Tracks)
                {
                    if (i.Type == Vlc.DotNet.Core.Interops.Signatures.MediaTrackTypes.Video)
                    {
                        if (CodecVideo != string.Empty)
                        {
                            CodecVideo += ", " + FourCCConverter.FromFourCC(i.CodecFourcc);
                        }
                        else
                        {
                            CodecVideo = FourCCConverter.FromFourCC(i.CodecFourcc);
                        }
                        VideoTrack videoTrack = i.TrackInfo as VideoTrack;
                        Hauteur = videoTrack?.Height.ToString();
                        Largeur = videoTrack?.Width.ToString();
                        Orientation = videoTrack?.Orientation.ToString();
                    }
                    else if (i.Type == Vlc.DotNet.Core.Interops.Signatures.MediaTrackTypes.Audio)
                    {
                        if (CodecSon != string.Empty)
                        {
                            CodecSon += ", " + FourCCConverter.FromFourCC(i.CodecFourcc);
                        }
                        else
                        {
                            CodecSon = FourCCConverter.FromFourCC(i.CodecFourcc);
                        }
                        AudioTrack audioTrack = i.TrackInfo as AudioTrack;
                        Cannaux = audioTrack?.Channels.ToString();
                        Rate = audioTrack?.Rate.ToString();
                    }
                    else if (i.Type == Vlc.DotNet.Core.Interops.Signatures.MediaTrackTypes.Text)
                    {
                        //CodecVideo = FourCCConverter.FromFourCC(i.CodecFourcc);
                        //SubtitleTrack subtitleTrack = i.TrackInfo as SubtitleTrack;
                        //Hauteur = subtitleTrack?.Encoding;
                    }
                }
            }

            new InfoFile(ref FileNameMedia, panel1.BackColor, ConvertVlcTimeToString(vlcControl1.Length, false), ref CodecVideo, ref Hauteur, ref Largeur, ref CodecSon, 
                ref Cannaux, ref Rate, ref Orientation, Langage).ShowDialog();
        }

        private void RéglageApplique()
        {
            // Application des réglages
            using (StreamReader reader = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Sky multi\appSettings"))
            {
                if (reader.ReadLine() == "True")
                {
                    ApercueProgressBar = true;
                }
                else
                {
                    ApercueProgressBar = false;
                }

                if (reader.ReadLine() == "True")
                {
                    ApercueTime = true;
                }
                else
                {
                    ApercueTime = false;
                }

                Langage = Convert.ToSByte(reader.ReadLine());

                switch (Langage) 
                {
                    case 0: // FR
                        button7.Text = Language.Francais.FormPrincipalButton7;
                        button6.Text = Language.Francais.FormPrincipalButton6;
                        button5.Text = Language.Francais.FormPrincipalButton5;
                        button1.Text = Language.Francais.FormPrincipalButton1;
                        label1.Text = Language.Francais.FormPrincipalLabel1;
                        break;

                    case 1: // EN
                        button7.Text = Language.English.FormPrincipalButton7;
                        button6.Text = Language.English.FormPrincipalButton6;
                        button5.Text = Language.English.FormPrincipalButton5;
                        button1.Text = Language.English.FormPrincipalButton1;
                        label1.Text = Language.English.FormPrincipalLabel1;
                        break;
                }

                more.TraduireBoutton(Langage);

                reader.Close();
            }
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            if (! File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Sky multi\appSettings"))
            {
                Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\");
                Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Sky multi");
                using (StreamWriter writer = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Sky multi\appSettings"))
                {
                    writer.Write("True\nTrue\n0");
                    writer.Close();
                }
            }

            RéglageApplique();

            if (Environment.GetCommandLineArgs().Last() != Application.ExecutablePath && Environment.GetCommandLineArgs().Last() != Application.StartupPath + @"Sky multi.dll")
            {
                if (File.Exists(Environment.GetCommandLineArgs().Last()))
                {
                    try
                    {
                        vlcControl1.Play(new Uri(Environment.GetCommandLineArgs().Last()));
                        FileNameMedia = Environment.GetCommandLineArgs().Last();
                        timer2.Enabled = true;
                    }
                    catch
                    {
                        // erreur
                    }
                }
            }
        }

        private void panel2_MouseEnter(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;
        }

        private void vlcControl1_EndReached(object sender, Vlc.DotNet.Core.VlcMediaPlayerEndReachedEventArgs e)  // Fin du multimedia
        {
            MediaFini = true;
        }

        private bool GetVideo()
        {
            if (vlcControl1.GetCurrentMedia() != null)
            {
                string CodecVideo = string.Empty;

                foreach (MediaTrack i in vlcControl1.GetCurrentMedia().Tracks)
                {
                    if (i.Type == Vlc.DotNet.Core.Interops.Signatures.MediaTrackTypes.Video)
                    {
                        CodecVideo = FourCCConverter.FromFourCC(i.CodecFourcc);
                    }
                }

                if (CodecVideo == string.Empty)
                {
                    CodecVideo = null;
                    return false;
                }
                else
                {
                    CodecVideo = string.Empty;
                    CodecVideo = null;
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        private bool GetAudio()
        {
            if (vlcControl1.GetCurrentMedia() != null)
            {
                string CodecAudio = string.Empty;

                foreach (MediaTrack i in vlcControl1.GetCurrentMedia().Tracks)
                {
                    if (i.Type == Vlc.DotNet.Core.Interops.Signatures.MediaTrackTypes.Audio)
                    {
                        CodecAudio = FourCCConverter.FromFourCC(i.CodecFourcc);
                    }
                }

                if (CodecAudio == string.Empty)
                {
                    CodecAudio = null;
                    return false;
                }
                else
                {
                    CodecAudio = string.Empty;
                    CodecAudio = null;
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        private bool IsPicture(ref string FilePath)
        {
            if (Path.GetExtension(FilePath) == ".raw")
            {
                return true;
            }

            Image image = null;
            try
            {
                image = Image.FromFile(FilePath);
                return true;
            }
            catch
            {
                image = null;
                return false;
            }
        }

        private void MultimediaDroite()
        {
            List<string> FileList = new List<string>(Directory.EnumerateFiles(Path.GetDirectoryName(FileNameMedia)));

            do
            {
                int index = 0;
                foreach (string i in FileList)
                {
                    if (i == FileNameMedia)
                    {
                        break;
                    }
                    index++;
                }

                if (index < FileList.Count() - 1)
                {
                    FileNameMedia = FileList[index + 1];
                }
                else
                {
                    FileNameMedia = FileList[0];
                }

                vlcControl1.Play(new Uri(FileNameMedia));
                System.Threading.Thread.Sleep(100);
            }
            while (GetVideo() == false && GetAudio() == false || Path.GetExtension(FileNameMedia) == ".nfo" || IsPicture(ref FileNameMedia));


            button8.BackgroundImage.Dispose();
            button8.BackgroundImage = Image.FromFile(Application.StartupPath + @"\Pause.png");
            pause = false;

            FileList.Clear();
            FileList = null;
        }

        private void MultimediaGauche()
        {
            List<string> FileList = new List<string>(Directory.EnumerateFiles(Path.GetDirectoryName(FileNameMedia)));

            do
            {
                int index = 0;
                foreach (string i in FileList)
                {
                    if (i == FileNameMedia)
                    {
                        break;
                    }
                    index++;
                }

                if (index > 0)
                {
                    FileNameMedia = FileList[index - 1];
                }
                else
                {
                    FileNameMedia = FileList[FileList.Count() - 1];
                }

                vlcControl1.Play(new Uri(FileNameMedia));
                System.Threading.Thread.Sleep(100);
            }
            while (GetVideo() == false && GetAudio() == false || Path.GetExtension(FileNameMedia) == ".nfo" || IsPicture(ref FileNameMedia));


            button8.BackgroundImage.Dispose();
            button8.BackgroundImage = Image.FromFile(Application.StartupPath + @"\Pause.png");
            pause = false;

            FileList.Clear();
            FileList = null;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            MultimediaGauche();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            MultimediaDroite();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            // son
            if (SoundPanel.Visible == true)
            {
                SoundPanel.Visible = false;
            }
            else
            {
                SoundPanel.Visible = true;
                SoundPanel.BringToFront();
            }
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            SoundPanel.Visible = false;
            ChoiceSpeed.CacheThis();
            more.Cache();
            Piste.Cache();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            SoundPanel.Visible = false;
            ChoiceSpeed.CacheThis();
            more.Cache();
            Piste.Cache();
        }

        private void vlcControl1_MouseDown(object sender, MouseEventArgs e)
        {
            SoundPanel.Visible = false;
            ChoiceSpeed.CacheThis();
            more.Cache();
            Piste.Cache();
        }

        private void SoundPanel_Volume(sbyte Volume)
        {
            vlcControl1.Audio.Volume = Volume;
        }

        private void ChoixVitesseLecture()
        {
            if (ChoiceSpeed.Visible == true)
            {
                ChoiceSpeed.CacheThis();
            }
            else
            {
                ChoiceSpeed.BringToFront();
                ChoiceSpeed.MontreThis();
            }
        }

        private void ChoiceSpeed_Speed(ref float Speed, ref bool speedMore)
        {
            vlcControl1.Rate = 1.0f;

            if (Speed == 1.0f)
            {
                return;
            }

            if (speedMore == true)
            {
                vlcControl1.Rate *= Speed;
            }
            else
            {
                vlcControl1.Rate /= Speed;
            }
        }

        private void timer8_Tick(object sender, EventArgs e)
        {
            // Netoyage de la mémoire

            GC.GetTotalMemory(false);
            GC.Collect(0, GCCollectionMode.Forced);
            GC.WaitForPendingFinalizers();
            GC.Collect(0, GCCollectionMode.Forced);
            GC.GetTotalMemory(true);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            more.BringToFront();
            if (more.GetView == false)
            {
                more.Montre();
            }
            else
            {
                more.Cache();
            }
        }

        private void PisteVideo()
        {
            Piste.BringToFront();
            if (Piste.GetView == false)
            {
                Piste.Montre(vlcControl1.Video.Tracks);
                Piste.EventButtonPerso += new EventButtonPersoHandler(DefineTrackVideo);
            }
            else
            {
                Piste.Cache();
            }
        }

        private void PisteAudio()
        {
            Piste.BringToFront();
            if (Piste.GetView == false)
            {
                Piste.Montre(vlcControl1.Audio.Tracks);
                Piste.EventButtonPerso += new EventButtonPersoHandler(DefineTrackAudio);
            }
            else
            {
                Piste.Cache();
            }
        }

        private void PisteSousTitre()
        {
            Piste.BringToFront();
            if (Piste.GetView == false)
            {
                Piste.Montre(vlcControl1.SubTitles);
                Piste.EventButtonPerso += new EventButtonPersoHandler(DefineTrackSubTitles);
            }
            else
            {
                Piste.Cache();
            }
        }

        private void DefineTrackVideo(ref int ID)
        {
            vlcControl1.Video.Tracks.Current = vlcControl1.Video.Tracks.All.ToList()[ID];
        }

        private void DefineTrackAudio(ref int ID)
        {
            vlcControl1.Audio.Tracks.Current = vlcControl1.Audio.Tracks.All.ToList()[ID];
        }

        private void DefineTrackSubTitles(ref int ID)
        {
            if (FileNameMedia == string.Empty)
            {
                if (Langage == 0)
                {
                    MessageBox.Show("Aucun média en cours de lecture!", "Sky multi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No media currently playing!", "Sky multi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                return;
            }

            if (ID == -1)
            {
                OpenFileDialog fileDialog = new OpenFileDialog();
                if (Langage == 0)
                {
                    fileDialog.Filter = "Tous les fichiers|*.*";
                }
                else
                {
                    fileDialog.Filter = "All the files|*.*";
                }

                if (fileDialog.ShowDialog() == DialogResult.OK)
                {
                    long TimeCode = vlcControl1.Time;
                    vlcControl1.SetMedia(@"file:///" + FileNameMedia, @"sub-file=" + fileDialog.FileName);
                    vlcControl1.Play();
                    vlcControl1.Time = TimeCode;
                }
                return;
            }
            vlcControl1.SubTitles.Current = vlcControl1.SubTitles.All.ToList()[ID];
        }
    }
}
