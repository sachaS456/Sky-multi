﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_multi
{
    internal delegate void EventButtonPersoHandler(ref int ID);

    internal partial class ButtonPerso : UserControl
    {
        internal EventButtonPersoHandler EventCliqueHandler = null;
        private int ID;
        
        internal ButtonPerso(int ID)
        {
            InitializeComponent();

            this.ID = ID;

            label1.BackColor = Color.FromArgb(0, 0, 0, 0);
        }

        internal string LabelText
        {
            set
            {
                label1.Text = value;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (EventCliqueHandler != null)
            {
                EventCliqueHandler(ref ID);
            }
        }

        private void ButtonPerso_Click(object sender, EventArgs e)
        {
            if (EventCliqueHandler != null)
            {
                EventCliqueHandler(ref ID);
            }
        }

        private void ButtonPerso_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(40, 250, 250, 250);
        }

        private void ButtonPerso_MouseLeave(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(64, 64, 64);
        }

        private void ButtonPerso_MouseDown(object sender, MouseEventArgs e)
        {
            this.BackColor = Color.FromArgb(100, 250, 250, 250);
        }

        private void ButtonPerso_MouseUp(object sender, MouseEventArgs e)
        {
            this.BackColor = Color.FromArgb(64, 64, 64);
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            this.BackColor = Color.FromArgb(100, 250, 250, 250);
        }

        private void label1_MouseUp(object sender, MouseEventArgs e)
        {
            this.BackColor = Color.FromArgb(64, 64, 64);
        }

        private void label1_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(40, 250, 250, 250);
        }
    }
}
